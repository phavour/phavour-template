<?php
namespace FirstPackage;

class Package extends \Phavour\Package
{
    public function __construct()
    {
        $this->dir = __DIR__;
        $this->namespace = __NAMESPACE__;
    }
}
