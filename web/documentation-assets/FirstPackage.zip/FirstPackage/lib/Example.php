<?php
namespace FirstPackage\lib;

class Example
{
    public function __construct()
    {
    }
}