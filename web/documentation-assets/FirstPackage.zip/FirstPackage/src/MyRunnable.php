<?php
namespace FirstPackage\src;

use Phavour\Runnable;

class MyRunnable extends Runnable
{
    public function init()
    {
        $this->view->setLayout('myHtmlLayout.phtml');
    }

    public function index()
    {
    }
}