<?php
return array(
    'First.myrunnable.route1' => array(
        'method' => 'GET|POST|PUT|DELETE',
        'path' => '/my/first/package',
        'runnable' => 'MyRunnable::index',
    )
);